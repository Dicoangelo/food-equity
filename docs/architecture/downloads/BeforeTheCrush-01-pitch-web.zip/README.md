# BeforeTheCrush — Pitch pack

[Repository](https://github.com/niatalwalkar/food-equity) · [Web gallery](index.html) · [Verified architecture](source/VERIFIED-ARCHITECTURE.md)

Repository snapshot `fcb4f76678713c55af3873acfc21e2871f44bcc7`. These illustrations do not verify the current live deployment. Human confirmation of recipient capacity, acceptance and execution remains necessary.

## From surplus alert to reviewed rescue plan

![A reviewed surplus offer moves through candidate retrieval and feasibility checks to a coordinator handoff. Evidence informs the proposal; a person confirms the next step.](web/01-pitch/01-pitch-overview-1920.webp)

A reviewed surplus offer moves through candidate retrieval and feasibility checks to a coordinator handoff. Evidence informs the proposal; a person confirms the next step.

[1920px WebP](web/01-pitch/01-pitch-overview-1920.webp) · [1920px JPEG](web/01-pitch/01-pitch-overview-1920.jpg) · [1280px WebP](web/01-pitch/01-pitch-overview-1280.webp)

## The coordinator stays in control

![The system prepares a primary match, up to two backups and outreach drafts. The coordinator contacts recipients to confirm capacity and acceptance, then opens directions.](web/01-pitch/02-human-handoff-1920.webp)

The system prepares a primary match, up to two backups and outreach drafts. The coordinator contacts recipients to confirm capacity and acceptance, then opens directions.

[1920px WebP](web/01-pitch/02-human-handoff-1920.webp) · [1920px JPEG](web/01-pitch/02-human-handoff-1920.jpg) · [1280px WebP](web/01-pitch/02-human-handoff-1280.webp)

Original PNG SHA-256 hashes and compressed asset checksums are in [web/manifest.json](web/manifest.json). [Generation provenance](provenance.json).
