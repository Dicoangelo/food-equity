# BeforeTheCrush — Research pack

[Repository](https://github.com/niatalwalkar/food-equity) · [Web gallery](index.html) · [Verified architecture](source/VERIFIED-ARCHITECTURE.md)

Repository snapshot `fcb4f76678713c55af3873acfc21e2871f44bcc7`. These illustrations do not verify the current live deployment. Human confirmation of recipient capacity, acceptance and execution remains necessary.

## Retrieve broadly, check explicitly, rank transparently

![Explicit checks cover capacity, storage, service, acceptance and the pickup clock. Missing facts are flagged for confirmation; eligible candidates are ranked, enriched with evidence and rechecked.](web/03-research/05-decision-method-1920.webp)

Explicit checks cover capacity, storage, service, acceptance and the pickup clock. Missing facts are flagged for confirmation; eligible candidates are ranked, enriched with evidence and rechecked.

[1920px WebP](web/03-research/05-decision-method-1920.webp) · [1920px JPEG](web/03-research/05-decision-method-1920.jpg) · [1280px WebP](web/03-research/05-decision-method-1280.webp)

## What the evidence can—and cannot—tell us

![Recipient profiles, neighborhood context and FoodKeeper references support retrieval and guidance, with explicit limits on what each source establishes.](web/03-research/06-data-provenance-1920.webp)

Recipient profiles, neighborhood context and FoodKeeper references support retrieval and guidance, with explicit limits on what each source establishes.

[1920px WebP](web/03-research/06-data-provenance-1920.webp) · [1920px JPEG](web/03-research/06-data-provenance-1920.jpg) · [1280px WebP](web/03-research/06-data-provenance-1280.webp)

Original PNG SHA-256 hashes and compressed asset checksums are in [web/manifest.json](web/manifest.json). [Generation provenance](provenance.json).
