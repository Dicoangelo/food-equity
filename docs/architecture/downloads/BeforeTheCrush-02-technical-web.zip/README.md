# BeforeTheCrush — Technical pack

[Repository](https://github.com/niatalwalkar/food-equity) · [Web gallery](index.html) · [Verified architecture](source/VERIFIED-ARCHITECTURE.md)

Repository snapshot `fcb4f76678713c55af3873acfc21e2871f44bcc7`. These illustrations do not verify the current live deployment. Human confirmation of recipient capacity, acceptance and execution remains necessary.

## Runtime and trust boundaries

![The browser connects to the Cloud Run FastAPI service. The broker uses Vertex AI and loopback MCP Toolbox; the optional Live voice lane stages input for review.](web/02-technical/03-runtime-architecture-1920.webp)

The browser connects to the Cloud Run FastAPI service. The broker uses Vertex AI and loopback MCP Toolbox; the optional Live voice lane stages input for review.

[1920px WebP](web/02-technical/03-runtime-architecture-1920.webp) · [1920px JPEG](web/02-technical/03-runtime-architecture-1920.jpg) · [1280px WebP](web/02-technical/03-runtime-architecture-1280.webp)

## Four read tools, explicit evidence paths

![Four read tools expose recipient retrieval, exact recipient evidence, tract context and pinned FoodKeeper guidance. FoodKeeper is a local reference, separate from BigQuery.](web/02-technical/04-mcp-data-topology-1920.webp)

Four read tools expose recipient retrieval, exact recipient evidence, tract context and pinned FoodKeeper guidance. FoodKeeper is a local reference, separate from BigQuery.

[1920px WebP](web/02-technical/04-mcp-data-topology-1920.webp) · [1920px JPEG](web/02-technical/04-mcp-data-topology-1920.jpg) · [1280px WebP](web/02-technical/04-mcp-data-topology-1280.webp)

Original PNG SHA-256 hashes and compressed asset checksums are in [web/manifest.json](web/manifest.json). [Generation provenance](provenance.json).
